# Tarea-AOP

Implementacion de los patrones **Adapter** y **Singleton** en Java usando:
- **POO** (Programacion Orientada a Objetos) — Seccion A
- **AOP** (Programacion Orientada a Aspectos con AspectJ) — Secciones B y C

---

## Requisitos previos

1. **Java 11 o superior** instalado.
   ```bash
   java -version
   ```
2. **Maven 3.6+** instalado y disponible en el PATH.
   ```bash
   mvn -version
   ```
   Si no tienes Maven: https://maven.apache.org/download.cgi

---

## Paso 1: Clonar el repositorio

```bash
git clone https://github.com/pepinxd28-glitch/Tarea-AOP.git
cd Tarea-AOP
```

---

## Paso 2: Compilar el proyecto

Desde la raiz del proyecto (donde esta el archivo `pom.xml`):

```bash
mvn compile
```

Maven descargara automaticamente las dependencias de AspectJ. Solo necesitas hacer esto una vez (o cada vez que cambies el codigo).

---

## Paso 3: Ejecutar cada seccion

Cada seccion tiene su propia clase `Main`. Usa el comando que corresponda:

### Seccion A – Adapter con POO (20%)

```bash
mvn exec:java -Dexec.mainClass="adapterpoo.Main"
```

**Salida esperada:**
```
Motor electrico conectado
```

**Archivos:** `src/adapterpoo/` — `Motor`, `MotorElectrico`, `AdaptadorMotor`, `Main`

---

### Seccion A – Singleton con POO (20%)

```bash
mvn exec:java -Dexec.mainClass="singletonpoo.Main"
```

**Salida esperada:**
```
Instancia creada
true
```

**Archivos:** `src/singletonpoo/` — `Configuracion`, `Main`

---

### Seccion B – Adapter con AOP (40%)

```bash
mvn exec:java -Dexec.mainClass="adapteraop.Main"
```

**Salida esperada:**
```
=== Seccion B: Adapter con AOP ===

Llamando a motor.encender():
[AdapterAspect] Adaptando llamada: encender() -> conectar()
Motor electrico conectado (metodo nativo: conectar)

MotorElectrico es instancia de Motor? true
```

**Archivos:** `src/adapteraop/` — `Motor`, `MotorElectrico`, `AdapterAspect.aj`, `Main`

---

### Seccion C – Singleton con AOP (40%)

```bash
mvn exec:java -Dexec.mainClass="singletonaop.Main"
```

**Salida esperada:**
```
=== Seccion C: Singleton con AOP ===

Creando c1 con: new Configuracion()
[SingletonAspect] Primera instancia - ejecutando constructor...
...
c1 == c2 : true
c1 == c3 : true
```

**Archivos:** `src/singletonaop/` — `Configuracion`, `SingletonAspect.aj`, `Main`

---

## Ejecutar todo de una vez (Windows)

En la raiz del proyecto, ejecuta:

```bash
run.bat
```

Ese script compila y corre las 4 secciones en orden.

---

## Estructura del proyecto

```
Tarea-AOP/
├── pom.xml                  ← Configuracion Maven + AspectJ
├── run.bat                  ← Script para ejecutar todas las secciones
├── README.md                ← Este archivo
└── src/
    ├── adapterpoo/          ← Seccion A: Adapter (POO)
    ├── singletonpoo/          ← Seccion A: Singleton (POO)
    ├── adapteraop/            ← Seccion B: Adapter (AOP)
    └── singletonaop/          ← Seccion C: Singleton (AOP)
```

---

## Descripcion de cada seccion

### Seccion A – POO

| Patron    | Clases principales |
|-----------|--------------------|
| Adapter   | `Motor`, `MotorElectrico`, `AdaptadorMotor` |
| Singleton | `Configuracion` (constructor privado + `getInstancia()`) |

### Seccion B – Adapter con AOP

El aspecto `AdapterAspect.aj` implementa el patron sin clase adaptadora:
- `declare parents`: `MotorElectrico` implementa `Motor`
- Declaracion inter-tipo: agrega `encender()` que llama a `conectar()`

**Beneficios vs POO:** no intrusivo, sin clase extra, centraliza la adaptacion.
**Limitaciones vs POO:** requiere AspectJ, menos visible al leer el codigo.

### Seccion C – Singleton con AOP

El aspecto `SingletonAspect.aj` intercepta `new Configuracion()` con un advice `around`:
- Primera llamada: crea la instancia
- Siguientes llamadas: devuelve la misma instancia

**Beneficios vs POO:** `Configuracion` queda como POJO limpio, reutilizable en otras clases.
**Limitaciones vs POO:** requiere AspectJ activo, el constructor sigue siendo publico.

---

## Problemas comunes

| Problema | Solucion |
|----------|----------|
| `mvn` no se reconoce | Instala Maven y agregalo al PATH |
| Error de compilacion AOP | Ejecuta `mvn compile` antes de correr |
| Seccion B o C no funciona con `javac` | Las secciones AOP **requieren Maven** (compilador AspectJ) |
