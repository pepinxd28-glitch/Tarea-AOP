package singletonaop;

/**
 * Seccion C - Singleton con AOP.
 * Ejecutar: mvn exec:java -Dexec.mainClass="singletonaop.Main"
 * Ver instrucciones completas en README.md
 *
 * Se usan llamadas directas a new Configuracion(). SingletonAspect intercepta
 * cada llamada y garantiza que todas las referencias apunten a la misma instancia.
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("=== Seccion C: Singleton con AOP ===\n");

        System.out.println("Creando c1 con: new Configuracion()");
        Configuracion c1 = new Configuracion();

        System.out.println("\nCreando c2 con: new Configuracion()");
        Configuracion c2 = new Configuracion();

        System.out.println("\nCreando c3 con: new Configuracion()");
        Configuracion c3 = new Configuracion();

        System.out.println("\n--- Verificacion ---");
        System.out.println("c1 == c2 : " + (c1 == c2));
        System.out.println("c1 == c3 : " + (c1 == c3));
        System.out.println("c2 == c3 : " + (c2 == c3));
        System.out.println("Ambiente de c1: " + c1.getAmbiente());

        // Modificar a traves de c2 afecta la misma instancia
        c2.setAmbiente("desarrollo");
        System.out.println("\nDespues de c2.setAmbiente(\"desarrollo\"):");
        System.out.println("c1.getAmbiente() = " + c1.getAmbiente() + "  (misma instancia que c2)");
    }
}
