package singletonaop;

/**
 * Clase de configuracion SIN logica de Singleton.
 * Es una clase ordinaria con constructor publico.
 * El aspecto SingletonAspect se encarga de garantizar que exista una sola instancia.
 */
public class Configuracion {

    private String ambiente;

    public Configuracion() {
        this.ambiente = "produccion";
        System.out.println("Constructor de Configuracion ejecutado (ambiente=" + ambiente + ")");
    }

    public String getAmbiente() {
        return ambiente;
    }

    public void setAmbiente(String ambiente) {
        this.ambiente = ambiente;
    }
}
