package singletonaop;

/**
 * Aspecto que implementa el patron Singleton utilizando Programacion Orientada a Aspectos.
 *
 * La clase Configuracion no contiene ninguna logica de Singleton (sin campo estatico,
 * sin constructor privado, sin metodo getInstancia). Este aspecto intercepta cada
 * llamada al constructor mediante un pointcut y, usando advice around, devuelve
 * siempre la misma instancia.
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * BENEFICIOS frente a la implementacion POO:
 *  + Separacion de responsabilidades: Configuracion es una clase POJO limpia.
 *  + No intrusivo: no se modifica la clase original para anadir el patron.
 *  + Reutilizable: el mismo mecanismo puede generalizarse con un aspecto abstracto
 *    y aplicarse a multiples clases sin duplicar codigo.
 *  + Facilita pruebas unitarias: al deshabilitar el aspecto se puede instanciar
 *    Configuracion libremente en los tests.
 *  + Aplicable a clases de terceros sin acceso al codigo fuente.
 *
 * LIMITACIONES frente a la implementacion POO:
 *  - El constructor sigue siendo publico: sin el tejedor activo no hay proteccion.
 *  - Requiere AspectJ en tiempo de compilacion y en tiempo de ejecucion.
 *  - La restriccion Singleton no es evidente leyendo solo la clase Configuracion.
 *  - Mayor complejidad de configuracion y depuracion del proyecto.
 *  - Si se instancia mediante reflexion (Class.newInstance), el aspecto puede no actuar.
 * ─────────────────────────────────────────────────────────────────────────────
 */
public aspect SingletonAspect {

    /** Unica instancia gestionada por el aspecto. */
    private static Configuracion instancia = null;

    /**
     * Pointcut: captura toda llamada al constructor de Configuracion
     * desde cualquier punto del codigo.
     */
    pointcut nuevaConfiguracion(): call(Configuracion.new(..));

    /**
     * Advice around: intercepta la construccion de Configuracion.
     * Si ya existe una instancia, la devuelve sin ejecutar el constructor.
     * Si no existe, la crea con proceed() y la almacena.
     */
    Configuracion around(): nuevaConfiguracion() {
        if (instancia == null) {
            System.out.println("[SingletonAspect] Primera instancia - ejecutando constructor...");
            instancia = proceed();
        } else {
            System.out.println("[SingletonAspect] Instancia ya existente - reutilizando.");
        }
        return instancia;
    }
}
