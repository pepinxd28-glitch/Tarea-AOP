package adapterpoo;

public class MotorElectrico {

    public void conectar() {
        System.out.println("Motor electrico conectado");
    }
}
