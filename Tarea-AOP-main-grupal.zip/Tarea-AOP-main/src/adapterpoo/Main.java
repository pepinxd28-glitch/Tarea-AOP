package adapterpoo;

/**
 * Seccion A - Adapter con POO.
 * Ejecutar: mvn exec:java -Dexec.mainClass="adapterpoo.Main"
 * Ver instrucciones completas en README.md
 */
public class Main {

    public static void main(String[] args) {

        MotorElectrico motorElectrico = new MotorElectrico();

        Motor motor = new AdaptadorMotor(motorElectrico);

        motor.encender();
    }
}