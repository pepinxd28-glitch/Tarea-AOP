package adapteraop;

/**
 * Interfaz objetivo (Target) del patron Adapter.
 * Representa el contrato que el cliente espera.
 */
public interface Motor {
    void encender();
}
