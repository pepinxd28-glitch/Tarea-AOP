package adapteraop;

/**
 * Clase Adaptada (Adaptee).
 * Tiene una interfaz incompatible con Motor: usa conectar() en lugar de encender().
 * NO implementa Motor ni conoce nada del patron Adapter.
 * El aspecto AdapterAspect se encarga de realizar la adaptacion.
 */
public class MotorElectrico {

    public void conectar() {
        System.out.println("Motor electrico conectado (metodo nativo: conectar)");
    }
}
