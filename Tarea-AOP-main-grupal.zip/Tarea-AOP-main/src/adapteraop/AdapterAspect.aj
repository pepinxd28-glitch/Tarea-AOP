package adapteraop;

/**
 * Aspecto que implementa el patron Adapter utilizando Programacion Orientada a Aspectos.
 *
 * En lugar de crear una clase AdaptadorMotor (como en POO), este aspecto usa dos
 * caracteristicas clave de AspectJ:
 *  1. declare parents: hace que MotorElectrico implemente la interfaz Motor.
 *  2. Declaracion inter-tipo: agrega el metodo encender() directamente a MotorElectrico.
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * BENEFICIOS frente a la implementacion POO:
 *  + No se requiere una clase Adaptadora adicional (AdaptadorMotor desaparece).
 *  + No intrusivo: Motor y MotorElectrico no son modificados en absoluto.
 *  + Separacion de responsabilidades: la logica de adaptacion vive en el aspecto.
 *  + Facilita adaptar clases de terceros (librerias externas) sin herencia ni composicion.
 *  + Centraliza la adaptacion: si cambia la interfaz, solo se modifica el aspecto.
 *
 * LIMITACIONES frente a la implementacion POO:
 *  - Requiere el compilador/tejedor de AspectJ (ajc); no funciona con javac estandar.
 *  - La relacion de adaptacion no es visible leyendo las clases implicadas.
 *  - Curva de aprendizaje: los desarrolladores deben conocer AOP para mantenerlo.
 *  - Menor portabilidad si el proyecto migra a un entorno sin soporte AspectJ.
 *  - Las herramientas de analisis estatico estandar pueden no detectar la implementacion.
 * ─────────────────────────────────────────────────────────────────────────────
 */
public aspect AdapterAspect {

    /**
     * Declaracion inter-tipo de jerarquia:
     * Le indica al tejedor de aspectos que MotorElectrico implementa Motor.
     * Esto ocurre en tiempo de compilacion, sin modificar el bytecode de MotorElectrico.
     */
    declare parents: MotorElectrico implements Motor;

    /**
     * Declaracion inter-tipo de metodo:
     * Agrega el metodo encender() a la clase MotorElectrico.
     * Implementa el "puente" de adaptacion llamando al metodo nativo conectar().
     */
    public void MotorElectrico.encender() {
        System.out.println("[AdapterAspect] Adaptando llamada: encender() -> conectar()");
        this.conectar();
    }
}
