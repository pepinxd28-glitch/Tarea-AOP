package adapteraop;

/**
 * Seccion B - Adapter con AOP.
 * Ejecutar: mvn exec:java -Dexec.mainClass="adapteraop.Main"
 * Ver instrucciones completas en README.md
 *
 * Gracias a AdapterAspect, MotorElectrico implementa Motor sin haber sido
 * modificado. No existe clase AdaptadorMotor; el aspecto hace el trabajo.
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("=== Seccion B: Adapter con AOP ===\n");

        MotorElectrico motorElectrico = new MotorElectrico();

        // AdapterAspect hizo que MotorElectrico implemente Motor;
        // por eso esta asignacion es valida sin ninguna clase adaptadora.
        Motor motor = motorElectrico;

        System.out.println("Llamando a motor.encender():");
        motor.encender();

        System.out.println("\nMotorElectrico es instancia de Motor? "
                + (motorElectrico instanceof Motor));
    }
}
