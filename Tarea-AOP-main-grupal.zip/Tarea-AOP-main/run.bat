@echo off
chcp 65001 >nul
echo ==========================================
echo   Tarea-AOP - Ejecutar todas las secciones
echo ==========================================
echo.

echo [1/5] Compilando proyecto...
call mvn -q compile
if errorlevel 1 (
    echo ERROR: La compilacion fallo. Verifica que Maven y Java esten instalados.
    pause
    exit /b 1
)
echo Compilacion exitosa.
echo.

echo ==========================================
echo   SECCION A - ADAPTER (POO)
echo   Comando: mvn exec:java -Dexec.mainClass="adapterpoo.Main"
echo ==========================================
call mvn -q exec:java -Dexec.mainClass=adapterpoo.Main
echo.

echo ==========================================
echo   SECCION A - SINGLETON (POO)
echo   Comando: mvn exec:java -Dexec.mainClass="singletonpoo.Main"
echo ==========================================
call mvn -q exec:java -Dexec.mainClass=singletonpoo.Main
echo.

echo ==========================================
echo   SECCION B - ADAPTER (AOP)
echo   Comando: mvn exec:java -Dexec.mainClass="adapteraop.Main"
echo ==========================================
call mvn -q exec:java -Dexec.mainClass=adapteraop.Main
echo.

echo ==========================================
echo   SECCION C - SINGLETON (AOP)
echo   Comando: mvn exec:java -Dexec.mainClass="singletonaop.Main"
echo ==========================================
call mvn -q exec:java -Dexec.mainClass=singletonaop.Main
echo.

echo ==========================================
echo   Todas las secciones ejecutadas.
echo ==========================================
pause
